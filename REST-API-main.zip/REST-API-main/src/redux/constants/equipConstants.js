export const GET_PRODUCT_SUCCESS = 'getProductSSuccess';
export const GET_PRODUCT_FAIL = 'getProductsFail';

export const GET_PRODUCT_DETAIL_SUCCESS = 'getProductDetailSuccess';
export const GET_PRODUCT_DETAIL_FAIL = 'getProductDetailFail';

export const GET_PRODUCT_CATEGORY_SUCCESS = 'getProductCategorySuccess';
export const GET_PRODUCT_CATEGORY_FAIL = 'getProductCategoryFail';