package com.krishi_sarthi.springmongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
