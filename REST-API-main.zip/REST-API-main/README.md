# REST-API
REST API  for performing CURD operations using Spring boot and Mongo-DB which can be used as a service to integrate projects with the backend.
